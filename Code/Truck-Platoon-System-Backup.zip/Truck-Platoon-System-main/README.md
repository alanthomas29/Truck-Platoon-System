# Distributed -Truck PlatooningSystems
Course              - Embedded System for Mechatronics
College             - FH Dortmund
Distributed Systems – Semester Project -Truck Platooning Scenario

Team Members : 
Alan Thomas         - 7209936
Anish Salvi         - 7210036
Ninad Dehadrai      - 7210380
Rohan Ijhare        - 7209800
